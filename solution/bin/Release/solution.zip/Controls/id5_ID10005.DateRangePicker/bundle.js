/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./DateRangePicker/DateRangePickerView.tsx"
/*!*************************************************!*\
  !*** ./DateRangePicker/DateRangePickerView.tsx ***!
  \*************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DateRangePickerView: () => (/* binding */ DateRangePickerView)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\nfunction _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }\nfunction _nonIterableRest() { throw new TypeError(\"Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.\"); }\nfunction _unsupportedIterableToArray(r, a) { if (r) { if (\"string\" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return \"Object\" === t && r.constructor && (t = r.constructor.name), \"Map\" === t || \"Set\" === t ? Array.from(r) : \"Arguments\" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }\nfunction _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }\nfunction _iterableToArrayLimit(r, l) { var t = null == r ? null : \"undefined\" != typeof Symbol && r[Symbol.iterator] || r[\"@@iterator\"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }\nfunction _arrayWithHoles(r) { if (Array.isArray(r)) return r; }\n/**\n * Fecha: 2026-09-12\n * Descripcion: Vista React del calendario, con navegacion mensual,\n * seleccion visual del rango y estados de inicio, fin y fechas intermedias.\n */\n;\nvar weekdays = [\"Lun\", \"Mar\", \"Mié\", \"Jue\", \"Vie\", \"Sáb\", \"Dom\"];\nvar months = [\"enero\", \"febrero\", \"marzo\", \"abril\", \"mayo\", \"junio\", \"julio\", \"agosto\", \"septiembre\", \"octubre\", \"noviembre\", \"diciembre\"];\nfunction toDate(value) {\n  if (!/^\\d{4}-\\d{2}-\\d{2}$/.test(value)) return null;\n  var _value$split$map = value.split(\"-\").map(Number),\n    _value$split$map2 = _slicedToArray(_value$split$map, 3),\n    year = _value$split$map2[0],\n    month = _value$split$map2[1],\n    day = _value$split$map2[2];\n  return new Date(year, month - 1, day);\n}\nfunction formatDate(date) {\n  return \"\".concat(date.getFullYear(), \"-\").concat(String(date.getMonth() + 1).padStart(2, \"0\"), \"-\").concat(String(date.getDate()).padStart(2, \"0\"));\n}\nfunction sameDate(first, second) {\n  return !!first && !!second && formatDate(first) === formatDate(second);\n}\nfunction createCalendarDays(month) {\n  var firstDay = new Date(month.getFullYear(), month.getMonth(), 1);\n  var mondayOffset = (firstDay.getDay() + 6) % 7;\n  var firstCell = new Date(month.getFullYear(), month.getMonth(), 1 - mondayOffset);\n  return Array.from({\n    length: 42\n  }, (_, index) => {\n    var date = new Date(firstCell.getFullYear(), firstCell.getMonth(), firstCell.getDate() + index);\n    return {\n      date,\n      day: date.getDate(),\n      isCurrentMonth: date.getMonth() === month.getMonth(),\n      key: formatDate(date)\n    };\n  });\n}\nclass DateRangePickerView extends react__WEBPACK_IMPORTED_MODULE_0__.Component {\n  constructor(props) {\n    var _a;\n    super(props);\n    this.selectDate = date => {\n      var start = toDate(this.props.startDate);\n      var end = toDate(this.props.endDate);\n      if (!start || start && end) this.props.onRangeChange(formatDate(date), \"\");else if (date < start) this.props.onRangeChange(formatDate(date), formatDate(start));else this.props.onRangeChange(formatDate(start), formatDate(date));\n    };\n    this.moveMonth = offset => {\n      this.setState(_ref => {\n        var visibleMonth = _ref.visibleMonth;\n        return {\n          visibleMonth: new Date(visibleMonth.getFullYear(), visibleMonth.getMonth() + offset, 1)\n        };\n      });\n    };\n    this.state = {\n      visibleMonth: (_a = toDate(props.startDate)) !== null && _a !== void 0 ? _a : new Date()\n    };\n  }\n  render() {\n    var _this$props = this.props,\n      startDate = _this$props.startDate,\n      endDate = _this$props.endDate,\n      disabled = _this$props.disabled;\n    var start = toDate(startDate);\n    var end = toDate(endDate);\n    var hasRange = !!start && !!end;\n    var summary = startDate && endDate ? \"\".concat(startDate, \"  \\u2192  \").concat(endDate) : startDate ? \"\".concat(startDate, \"  \\u2192  Selecciona una fecha final\") : \"Selecciona una fecha de inicio\";\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"section\", {\n      className: \"drp-root\",\n      \"aria-label\": \"Selector de rango de fechas\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: \"drp-header\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      className: \"drp-kicker\"\n    }, \"RANGO DE FECHAS\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: \"drp-summary\"\n    }, summary)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: \"drp-status \".concat(hasRange ? \"is-complete\" : \"\")\n    }, hasRange ? \"Listo\" : \"En selección\")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: \"drp-calendar\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: \"drp-monthbar\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n      type: \"button\",\n      className: \"drp-nav\",\n      onClick: () => this.moveMonth(-1),\n      disabled: disabled,\n      \"aria-label\": \"Mes anterior\"\n    }, \"\\u2039\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"strong\", null, months[this.state.visibleMonth.getMonth()], \" \", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", null, this.state.visibleMonth.getFullYear())), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n      type: \"button\",\n      className: \"drp-nav\",\n      onClick: () => this.moveMonth(1),\n      disabled: disabled,\n      \"aria-label\": \"Mes siguiente\"\n    }, \"\\u203A\")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: \"drp-weekdays\"\n    }, weekdays.map(day => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      key: day\n    }, day))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: \"drp-grid\"\n    }, createCalendarDays(this.state.visibleMonth).map(_ref2 => {\n      var date = _ref2.date,\n        day = _ref2.day,\n        isCurrentMonth = _ref2.isCurrentMonth,\n        key = _ref2.key;\n      var isStart = sameDate(date, start);\n      var isEnd = sameDate(date, end);\n      var isBetween = !!start && !!end && date > start && date < end;\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n        key: key,\n        type: \"button\",\n        className: \"drp-day \".concat(isCurrentMonth ? \"\" : \"is-muted\", \" \").concat(isBetween ? \"is-between\" : \"\", \" \").concat(isStart ? \"is-start\" : \"\", \" \").concat(isEnd ? \"is-end\" : \"\"),\n        onClick: () => this.selectDate(date),\n        disabled: disabled\n      }, day);\n    }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: \"drp-footer\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      className: \"drp-dot\"\n    }), \" \", hasRange ? \"Rango seleccionado\" : \"Haz clic en dos fechas para completar el rango\"));\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./DateRangePicker/DateRangePickerView.tsx?\n}");

/***/ },

/***/ "./DateRangePicker/index.ts"
/*!**********************************!*\
  !*** ./DateRangePicker/index.ts ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DateRangePicker: () => (/* binding */ DateRangePicker)\n/* harmony export */ });\n/* harmony import */ var _DateRangePickerView__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DateRangePickerView */ \"./DateRangePicker/DateRangePickerView.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass DateRangePicker {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this.startDate = \"\";\n    this.endDate = \"\";\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    var _a, _b, _c, _d;\n    var inputStart = (_b = (_a = context.parameters.initialStartDate) === null || _a === void 0 ? void 0 : _a.raw) !== null && _b !== void 0 ? _b : \"\";\n    var inputEnd = (_d = (_c = context.parameters.initialEndDate) === null || _c === void 0 ? void 0 : _c.raw) !== null && _d !== void 0 ? _d : \"\";\n    if (!this.startDate && inputStart) this.startDate = inputStart;\n    if (!this.endDate && inputEnd) this.endDate = inputEnd;\n    var props = {\n      startDate: this.startDate,\n      endDate: this.endDate,\n      onRangeChange: (startDate, endDate) => {\n        this.startDate = startDate;\n        this.endDate = endDate;\n        this.notifyOutputChanged();\n      },\n      disabled: context.mode.isControlDisabled\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_DateRangePickerView__WEBPACK_IMPORTED_MODULE_0__.DateRangePickerView, props);\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {\n      startDate: this.startDate,\n      endDate: this.endDate\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./DateRangePicker/index.ts?\n}");

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = (module) => {
/******/ 		const getter = module && module.__esModule ?
/******/ 			() => (module['default']) :
/******/ 			() => (module);
/******/ 		__webpack_require__.d(getter, { a: getter });
/******/ 		return getter;
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	// define getter/value functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		for(var key in definition) {
/******/ 			if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 				Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 			}
/******/ 		}
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = (exports) => {
/******/ 		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	let __webpack_exports__ = __webpack_require__("./DateRangePicker/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ID10005.DateRangePicker', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DateRangePicker);
} else {
	var ID10005 = ID10005 || {};
	ID10005.DateRangePicker = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DateRangePicker;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}