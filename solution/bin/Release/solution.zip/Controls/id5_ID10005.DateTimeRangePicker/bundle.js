/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./DateTimeRangePicker/DateTimeRangePickerView.tsx"
/*!*********************************************************!*\
  !*** ./DateTimeRangePicker/DateTimeRangePickerView.tsx ***!
  \*********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DateTimeRangePickerView: () => (/* binding */ DateTimeRangePickerView)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/**\n * Fecha: 2026-09-12\n * Descripcion: Vista de seleccion de fecha y hora para ambos extremos del rango.\n */\n\nfunction formatDateTime(value, dateFormat, timeFormat) {\n  if (!value) return \"Sin seleccionar\";\n  var date = new Date(\"\".concat(value, \":00\"));\n  if (Number.isNaN(date.getTime())) return value;\n  var year = String(date.getFullYear());\n  var month = String(date.getMonth() + 1).padStart(2, \"0\");\n  var day = String(date.getDate()).padStart(2, \"0\");\n  var normalizedDateFormat = dateFormat.toUpperCase();\n  var dateValue = normalizedDateFormat === \"DD/MM/YYYY\" ? \"\".concat(day, \"/\").concat(month, \"/\").concat(year) : normalizedDateFormat === \"MM/DD/YYYY\" ? \"\".concat(month, \"/\").concat(day, \"/\").concat(year) : normalizedDateFormat === \"YYYY/MM/DD\" ? \"\".concat(year, \"/\").concat(month, \"/\").concat(day) : normalizedDateFormat === \"YYYY.MM.DD\" ? \"\".concat(year, \".\").concat(month, \".\").concat(day) : normalizedDateFormat === \"YYYYMMDD\" ? \"\".concat(year).concat(month).concat(day) : normalizedDateFormat === \"DD-MM-YYYY\" ? \"\".concat(day, \"-\").concat(month, \"-\").concat(year) : normalizedDateFormat === \"MM-DD-YYYY\" ? \"\".concat(month, \"-\").concat(day, \"-\").concat(year) : normalizedDateFormat === \"DD.MM.YYYY\" ? \"\".concat(day, \".\").concat(month, \".\").concat(year) : normalizedDateFormat === \"MM.DD.YYYY\" ? \"\".concat(month, \".\").concat(day, \".\").concat(year) : normalizedDateFormat === \"DDMMYYYY\" ? \"\".concat(day).concat(month).concat(year) : normalizedDateFormat === \"MMDDYYYY\" ? \"\".concat(month).concat(day).concat(year) : \"\".concat(year, \"-\").concat(month, \"-\").concat(day);\n  var timeValue = date.toLocaleTimeString([], {\n    hour: \"2-digit\",\n    minute: \"2-digit\",\n    second: timeFormat === \"24:00:00\" || timeFormat === \"12:00:00\" ? \"2-digit\" : undefined,\n    hour12: timeFormat.startsWith(\"12\")\n  });\n  return \"\".concat(dateValue, \" \\xB7 \").concat(timeValue);\n}\nclass DateTimeRangePickerView extends react__WEBPACK_IMPORTED_MODULE_0__.Component {\n  constructor() {\n    super(...arguments);\n    this.updateStartDateTime = value => {\n      this.props.onRangeChange(value, this.props.endDateTime);\n    };\n    this.updateEndDateTime = value => {\n      this.props.onRangeChange(this.props.startDateTime, value);\n    };\n  }\n  render() {\n    var _this$props = this.props,\n      startDateTime = _this$props.startDateTime,\n      endDateTime = _this$props.endDateTime,\n      dateFormat = _this$props.dateFormat,\n      timeFormat = _this$props.timeFormat,\n      disabled = _this$props.disabled;\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"section\", {\n      className: \"dtrp-root\",\n      \"aria-label\": \"Selector de rango de fecha y hora\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"header\", {\n      className: \"dtrp-header\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      className: \"dtrp-kicker\"\n    }, \"RANGO DE FECHA Y HORA\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"h2\", null, \"Define tu ventana\")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      className: \"dtrp-status \".concat(startDateTime && endDateTime ? \"is-complete\" : \"\")\n    }, startDateTime && endDateTime ? \"Listo\" : \"Pendiente\")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: \"dtrp-fields\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"label\", {\n      className: \"dtrp-field\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", null, \"Inicio\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"input\", {\n      type: \"date\",\n      value: startDateTime.slice(0, 10),\n      onChange: event => this.updateStartDateTime(\"\".concat(event.target.value, \"T\").concat(startDateTime.slice(11, 16) || \"00:00\")),\n      disabled: disabled\n    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"input\", {\n      type: \"time\",\n      value: startDateTime.slice(11, 16),\n      onChange: event => this.updateStartDateTime(\"\".concat(startDateTime.slice(0, 10), \"T\").concat(event.target.value)),\n      disabled: disabled\n    }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"label\", {\n      className: \"dtrp-field\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", null, \"Fin\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"input\", {\n      type: \"date\",\n      value: endDateTime.slice(0, 10),\n      onChange: event => this.updateEndDateTime(\"\".concat(event.target.value, \"T\").concat(endDateTime.slice(11, 16) || \"00:00\")),\n      disabled: disabled\n    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"input\", {\n      type: \"time\",\n      value: endDateTime.slice(11, 16),\n      onChange: event => this.updateEndDateTime(\"\".concat(endDateTime.slice(0, 10), \"T\").concat(event.target.value)),\n      disabled: disabled\n    })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: \"dtrp-summary\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"small\", null, \"INICIO\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"strong\", null, formatDateTime(startDateTime, dateFormat, timeFormat))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"small\", null, \"FIN\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"strong\", null, formatDateTime(endDateTime, dateFormat, timeFormat)))));\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./DateTimeRangePicker/DateTimeRangePickerView.tsx?\n}");

/***/ },

/***/ "./DateTimeRangePicker/index.ts"
/*!**************************************!*\
  !*** ./DateTimeRangePicker/index.ts ***!
  \**************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DateTimeRangePicker: () => (/* binding */ DateTimeRangePicker)\n/* harmony export */ });\n/* harmony import */ var _DateTimeRangePickerView__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DateTimeRangePickerView */ \"./DateTimeRangePicker/DateTimeRangePickerView.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass DateTimeRangePicker {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this.startDateTime = \"\";\n    this.endDateTime = \"\";\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    var _a, _b, _c, _d, _e, _f, _g, _h;\n    var inputStart = (_b = (_a = context.parameters.initialStartDateTime) === null || _a === void 0 ? void 0 : _a.raw) !== null && _b !== void 0 ? _b : \"\";\n    var inputEnd = (_d = (_c = context.parameters.initialEndDateTime) === null || _c === void 0 ? void 0 : _c.raw) !== null && _d !== void 0 ? _d : \"\";\n    if (!this.startDateTime && inputStart) this.startDateTime = inputStart;\n    if (!this.endDateTime && inputEnd) this.endDateTime = inputEnd;\n    var props = {\n      startDateTime: this.startDateTime,\n      endDateTime: this.endDateTime,\n      dateFormat: String((_f = (_e = context.parameters.format) === null || _e === void 0 ? void 0 : _e.raw) !== null && _f !== void 0 ? _f : \"YYYY-MM-DD\"),\n      timeFormat: String((_h = (_g = context.parameters.timeFormat) === null || _g === void 0 ? void 0 : _g.raw) !== null && _h !== void 0 ? _h : \"24\"),\n      disabled: context.mode.isControlDisabled,\n      onRangeChange: (startDateTime, endDateTime) => {\n        this.startDateTime = startDateTime;\n        this.endDateTime = endDateTime;\n        this.notifyOutputChanged();\n      }\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_DateTimeRangePickerView__WEBPACK_IMPORTED_MODULE_0__.DateTimeRangePickerView, props);\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {\n      startDateTime: this.startDateTime,\n      endDateTime: this.endDateTime\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./DateTimeRangePicker/index.ts?\n}");

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = (module) => {
/******/ 		const getter = module && module.__esModule ?
/******/ 			() => (module['default']) :
/******/ 			() => (module);
/******/ 		__webpack_require__.d(getter, { a: getter });
/******/ 		return getter;
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	// define getter/value functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		for(var key in definition) {
/******/ 			if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 				Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 			}
/******/ 		}
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = (exports) => {
/******/ 		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	let __webpack_exports__ = __webpack_require__("./DateTimeRangePicker/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ID10005.DateTimeRangePicker', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DateTimeRangePicker);
} else {
	var ID10005 = ID10005 || {};
	ID10005.DateTimeRangePicker = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DateTimeRangePicker;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}